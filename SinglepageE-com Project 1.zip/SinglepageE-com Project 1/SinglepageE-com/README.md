# Simple_Ecom
Single Page for E-commerce using html and css only.
